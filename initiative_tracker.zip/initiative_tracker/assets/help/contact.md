# Contact
Please feel free to report any issues, bugs, or feature requests either through email, or in the GitHub Repo. If you have any questions, please do not hesitate to contact me.

Thank you so much for using this app!

* Gitub: [tsonnen](url:https://github.com/tsonnen)
* Twitter: [@tsonnen67](url:https://twitter.com/tsonnen67)
* E-mail: [tsonnenapps@gmail.com](url:mailto:tsonnenapps@gmail.com)