# Party Mangement
You can save a party for use later through the menu dropdown. These parties will persist between launches. 

These parties can be managed and loaded from the party management dialog. While in this dialog, tapping on a a party will load it and holding a party will delete it. By default, there are confirmation dialogs that will be displayed when either of these actions are triggered, if desired, these can be turned off in the [Settings](help:settings).