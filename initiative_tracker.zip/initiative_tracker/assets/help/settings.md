# Settings
You can specify what type of theme you would like to use, as well as the number and type of dice you would like to use for auto-rolling the initiative.

There are also checkboxes to turn off the confirmation dialogs for party management.