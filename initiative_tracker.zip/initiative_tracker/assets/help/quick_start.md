# Quick Start
To start adding characters, tap on the plus button in the middle of the bottom on the main page. This will take you to the [add a character](help:adding_a_character) screen.

For more information on this screen, please see [Home Screen](help:home_screen).